# LeadCraft Pro - Minimal SaaS Starter (with Threads support)

This is a minimal demo project that includes:
- Lead creation API: POST /api/leads
- Lead listing: GET /api/leads
- Manual Threads post: POST /api/threads
- Frontend dashboard: / (simple HTML + JS)
- Toggle auto-posting by editing backend/config.js (autoPostToThreads: true/false)

## Deploy on Render (free)
1. Create a GitHub repository and push this project.
2. On Render, create a **Web Service** and connect the repo.
   - Environment: **Node**
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Port: `4000`
3. (Optional) In Render's dashboard set environment variables:
   - THREADS_ACCESS_TOKEN
   - THREADS_USER_ID

## Notes
- This MVP uses an in-memory store for leads (no DB). For production, connect PostgreSQL and persist leads.
- If THREADS_ACCESS_TOKEN and THREADS_USER_ID are not set, Threads calls are simulated (safe for testing).
