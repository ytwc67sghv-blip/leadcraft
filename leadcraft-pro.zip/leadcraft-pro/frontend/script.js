const modeEl = document.getElementById('mode');
const leadsDiv = document.getElementById('leads');
const createBtn = document.getElementById('create');
const postBtn = document.getElementById('postThreads');

async function fetchLeads() {
  const res = await fetch('/api/leads');
  const data = await res.json();
  leadsDiv.innerHTML = '';
  data.forEach(l => {
    const el = document.createElement('div');
    el.className = 'lead';
    el.innerHTML = `<strong>#${l.id}</strong> ${l.company || ''} / ${l.contact || ''} <br/> ${l.email || ''} <br/> ${l.message || ''} <br/> ${l.threads_post ? '<em>Threads: posted</em>' : (l.threads_error ? '<em style="color:red">Threads error</em>' : '')}`;
    leadsDiv.appendChild(el);
  });
}

// read mode from server by checking a JSON endpoint (we derive from root page)
async function loadMode() {
  try {
    const res = await fetch('/api/threads/mode');
    const j = await res.json();
    modeEl.innerText = j.auto ? '自動投稿ON' : '手動投稿モード';
  } catch (e) {
    modeEl.innerText = '不明（mode endpoint error）';
  }
}

createBtn.onclick = async () => {
  const company = document.getElementById('company').value;
  const contact = document.getElementById('contact').value;
  const email = document.getElementById('email').value;
  const message = document.getElementById('message').value;
  const res = await fetch('/api/leads', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ company, contact, email, message })
  });
  if (res.ok) {
    document.getElementById('company').value='';
    document.getElementById('contact').value='';
    document.getElementById('email').value='';
    document.getElementById('message').value='';
    await fetchLeads();
  } else {
    alert('Error creating lead');
  }
};

postBtn.onclick = async () => {
  const text = document.getElementById('threadsText').value;
  if (!text) { alert('Enter text'); return; }
  const res = await fetch('/api/threads', {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ text })
  });
  const j = await res.json();
  if (res.ok) {
    alert('Posted (or simulated). Check response in console.'); console.log(j);
    document.getElementById('threadsText').value='';
  } else {
    alert('Post failed: ' + (j.error || 'unknown'));
  }
};

loadMode();
fetchLeads();
setInterval(fetchLeads, 5000);
