import fetch from "node-fetch";

/*
  threadsService.postToThreads(message)

  Behavior:
  - If THREADS_ACCESS_TOKEN and THREADS_USER_ID env vars are set, it will attempt to call the official Graph API endpoint:
      POST https://graph.threads.net/v1.0/{userId}/threads
    with body: { text: message }
  - If env vars are missing, it will simulate a response (for local testing and to avoid accidental API calls).
*/

export async function postToThreads(message) {
  const token = process.env.THREADS_ACCESS_TOKEN;
  const userId = process.env.THREADS_USER_ID;

  if (!token || !userId) {
    // Simulate posting when no token provided
    return {
      simulated: true,
      text: message,
      created_at: new Date().toISOString()
    };
  }

  const url = `https://graph.threads.net/v1.0/${userId}/threads`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ text: message })
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Threads API error: ${res.status} ${body}`);
  }
  const data = await res.json();
  return data;
}
