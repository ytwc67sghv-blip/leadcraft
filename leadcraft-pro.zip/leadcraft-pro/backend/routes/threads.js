import express from "express";
import { postToThreads } from "../services/threadsService.js";

const router = express.Router();

// Manual post endpoint
router.post("/", async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "text is required" });
    const result = await postToThreads(text);
    res.json({ ok: true, result });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
