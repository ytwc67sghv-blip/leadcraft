import express from "express";
import { postToThreads } from "../services/threadsService.js";
import { config } from "../config.js";

const router = express.Router();

// In-memory leads store (for MVP). Replace with DB in production.
const leads = [];
let idSeq = 1;

router.get("/", (req, res) => {
  res.json(leads);
});

router.post("/", async (req, res) => {
  try {
    const { company, contact, email, message } = req.body;
    const lead = {
      id: idSeq++,
      company: company || null,
      contact: contact || null,
      email: email || null,
      message: message || null,
      created_at: new Date().toISOString()
    };
    leads.push(lead);

    // Auto-post to Threads if mode enabled
    if (config.autoPostToThreads) {
      const text = `新しいリード: ${lead.company || '無名'}, 担当: ${lead.contact || '不明'} - ${lead.message || ''}`;
      try {
        const r = await postToThreads(text);
        lead.threads_post = r;
      } catch (e) {
        lead.threads_error = (e && e.message) || String(e);
      }
    }

    res.status(201).json(lead);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
