export const config = {
  // Set to true to auto-post to Threads when a new lead is created.
  // You can change this in GitHub (commit) or set an environment variable in Render and read it here if you prefer.
  autoPostToThreads: false
};
