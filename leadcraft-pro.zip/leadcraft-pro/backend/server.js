import express from "express";
import cors from "cors";
import { config } from "./config.js";
import leadsRouter from "./routes/leads.js";
import threadsRouter from "./routes/threads.js";

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/leads", leadsRouter);
app.use("/api/threads", threadsRouter);

app.get("/", (req, res) => {
  res.sendFile(new URL('../frontend/index.html', import.meta.url).pathname);
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`✅ LeadCraft Pro running on port ${port} - autoPostToThreads=${config.autoPostToThreads}`));
